# Knip report

## Unused dependencies (2)

| Name                         | Location     | Severity |
| :--------------------------- | :----------- | :------- |
| @backstage/plugin-home-react | package.json | error    |
| @mui/styles                  | package.json | error    |

## Unused devDependencies (3)

| Name                        | Location     | Severity |
| :-------------------------- | :----------- | :------- |
| @testing-library/user-event | package.json | error    |
| @backstage/core-app-api     | package.json | error    |
| msw                         | package.json | error    |

