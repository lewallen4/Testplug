# Dynamic Home Page plugin

This is a dynamic version of the upstream [home page plugin](https://github.com/backstage/backstage/tree/master/plugins/home).

Instead of manually adding supported "home page cards" to a custom route, it allows dynamic plugins to expose such cards.
